import { Component } from '@angular/core';
import { AlertController } from 'ionic-angular';
import { NavController } from 'ionic-angular';
import {Md5} from 'ts-md5/dist/md5';
import { SecureStorage } from 'ionic-native';
import { PushRegisterService } from '../../app/push-service'


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  username:string;
  password:string;
  secureStorage: SecureStorage = new SecureStorage();

  constructor(public alerCtrl: AlertController, public navCtrl: NavController, push: PushRegisterService) {
    push.register(); 
  }

  Login(){
      if (this.username && this.password){
        this.ValidaUsuario();
      }else{
        this.AlertaErro();
      }
  }

  AlertaSucesso() {
    let alert = this.alerCtrl.create({
      title: 'Login Sucesso!',
      message: 'Usuario logado:\nUsername:' + this.username + '\nPassword:' + this.password,
      buttons: ['Ok']
    });
    alert.present()
  }

  AlertaErro() {
    let alert = this.alerCtrl.create({
      title: 'Login Error!',
      message: 'Por favor, verifique os campos',
      buttons: ['Ok']
    });
    alert.present()
  }

  ErroLogin() {
    let alert = this.alerCtrl.create({
      title: 'Login Error!',
      message: 'Usuario e/ou senha invalidas.',
      buttons: ['Ok']
    });
    alert.present()
  }

  AlertaCadastro() {
    let alert = this.alerCtrl.create({
      title: 'Cadastro!',
      message: 'Usuario cadastrado.',
      buttons: ['Ok']
    });
    alert.present()
  }

  ExibeErro(msg : string) {
    let alert = this.alerCtrl.create({
      title: 'Error!',
      message: msg,
      buttons: ['Ok']
    });
    alert.present()
  }

  ValidaUsuario(){
    this.secureStorage.create('login')
        .then(
           () => {
           this.secureStorage.get(this.username)
            .then(
              data => {
                if(data == Md5.hashStr(this.password).toString()){
                  this.AlertaSucesso();
                }else{
                  this.ErroLogin();
                }
              },
              error => {
                this.secureStorage.set(this.username, Md5.hashStr(this.password).toString())
                 .then(
                   data => this.AlertaCadastro(),
                   error => this.ExibeErro(error)
                );
              }
           );
           },
           error => this.ExibeErro(error)
        );
  }
}
